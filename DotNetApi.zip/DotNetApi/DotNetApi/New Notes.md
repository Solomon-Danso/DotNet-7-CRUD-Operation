#  MainController.cs 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DotNetApi.Models;
using Microsoft.AspNetCore.Mvc;

namespace DotNetApi.Controllers
{
    [ApiController]
    [Route("api/MallController")]
   public class MallController:ControllerBase{
    [HttpGet]
    public IEnumerable<MallModel>GetModel(){
        return new List<MallModel>{
            new MallModel{Id=1, Name="Kofi"},
            new MallModel{Id=2, Name="Ama"},
            new MallModel{Id=3, Name="Yaa"},
            new MallModel{Id=4, Name="Akos"},
            new MallModel{Id=5, Name="Kwame"},
            new MallModel{Id=6, Name="Kojo"},
        };
    }
   }
}

We may have some field in the model that we don't want to expose it to the user. So we can just create a DTO which will function as a wrapper between the model and the controller

in the model folder, create a folder named DTO and add this code to it

# MallDTO.cs
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DotNetApi.Models.Dto
{
    public class MallDto
    {
        public int Id { get; set; }
        public string Name { get; set; } = "Name";
    }
}

# The new controller class will be this
# MallController.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DotNetApi.Models.Dto;
using Microsoft.AspNetCore.Mvc;

namespace DotNetApi.Controllers
{
    [ApiController]
    [Route("api/Mall")]
    public class MallController : ControllerBase
    {
        [HttpGet]
        public IEnumerable<MallDTO> GetMall(){
            return new List<MallDTO>{
                new MallDTO{Id = 1, Name = "Solomon"},
                new MallDTO{Id = 2, Name = "Whiskey"},
                new MallDTO{Id = 3, Name = "Jack"},
                new MallDTO{Id = 4, Name = "Jill"},
                new MallDTO{Id = 5, Name = "Max"},
                new MallDTO{Id = 6, Name = "Charlie"},

            };

        }
    }
}


# Create a Data folder in the root project directory and add a class MallStore
# Inside the MallStore class, add the following code 

# MallStore.cs 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DotNetApi.Models.Dto;

namespace DotNetApi.Data
{
    public static class MallStore
    {
     public static List<MallDTO> MallList =  new List<MallDTO>{
                new MallDTO{Id = 1, Name = "Solomon"},
                new MallDTO{Id = 2, Name = "Whiskey"},
                new MallDTO{Id = 3, Name = "Jack"},
                new MallDTO{Id = 4, Name = "Jill"},
                new MallDTO{Id = 5, Name = "Max"},
                new MallDTO{Id = 6, Name = "Charlie"},

            };
    }
}


# The mall controller will look like this:
MallController.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DotNetApi.Data;
using DotNetApi.Models.Dto;
using Microsoft.AspNetCore.Mvc;

namespace DotNetApi.Controllers
{
    [ApiController]
    [Route("api/Mall")]
    public class MallController : ControllerBase
    {
        [HttpGet]
        public IEnumerable<MallDTO> GetMall(){
            return MallStore.MallList;

        }
    }
}

# Crud Operation Even Becomes Sweeter and Tasty
# HTTP GET Request FOR ALL AND SPECIFIC ITEMS

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DotNetApi.Data;
using DotNetApi.Models.Dto;
using Microsoft.AspNetCore.Mvc;

namespace DotNetApi.Controllers
{
    [ApiController]
    [Route("api/Mall")]
    public class MallController : ControllerBase
    {
        [HttpGet]
        public IEnumerable<MallDTO> GetMall(){
            return MallStore.MallList;

        }

         [HttpGet("Id")]
        public MallDTO GetOneMall(int Id){

            return MallStore.MallList.FirstOrDefault(x=>x.Id == Id);
            

        }
    }
}

# When we create an api, we are interested in the responds code 

MallController.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DotNetApi.Data;
using DotNetApi.Models.Dto;
using Microsoft.AspNetCore.Mvc;

namespace DotNetApi.Controllers
{
    [ApiController]
    [Route("api/Mall")]
    public class MallController : ControllerBase
    {
        [HttpGet]
        public ActionResult<IEnumerable<MallDTO>> GetMall(){
            return Ok(MallStore.MallList);

        }

         [HttpGet("Id")]
        public ActionResult<MallDTO> GetOneMall(int Id){
            if (Id <= 0){
                return BadRequest();
            }
            var Mall = MallStore.MallList.FirstOrDefault(x=>x.Id == Id);
            if (Mall == null){
                return NotFound();
            }
            return Ok(Mall);
            

        }
    }
}



#   We can also document the status codes for our application


using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DotNetApi.Data;
using DotNetApi.Models.Dto;
using Microsoft.AspNetCore.Mvc;

namespace DotNetApi.Controllers
{
    [ApiController]
    [Route("api/Mall")]
    public class MallController : ControllerBase
    {
/*

            GET REQUEST AND ID CODES


*/     
        [HttpGet]
         [ProducesResponseType(StatusCodes.Status200OK)]
        public ActionResult<IEnumerable<MallDTO>> GetMall(){
            return Ok(MallStore.MallList);

        }


         [HttpGet("Id")]
         [ProducesResponseType(StatusCodes.Status200OK)]
         [ProducesResponseType(StatusCodes.Status400BadRequest)]
         [ProducesResponseType(StatusCodes.Status404NotFound)]

        public ActionResult<MallDTO> GetOneMall(int Id){
            if (Id <= 0){
                return BadRequest();
            }
            var Mall = MallStore.MallList.FirstOrDefault(x=>x.Id == Id);
            if (Mall == null){
                return NotFound();
            }
            return Ok(Mall);
        }



    /*
    
            HTTP POST REQUEST 
    
    */

    [HttpPost]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public ActionResult<MallDTO> CreateMall([FromBody]MallDTO mallDTO){

    if(mallDTO == null){
        return BadRequest(mallDTO);
    } 

    if(mallDTO.Id>0){
        return StatusCode(StatusCodes.Status500InternalServerError);
    }
    mallDTO.Id = MallStore.MallList.OrderByDescending(u=>u.Id).FirstOrDefault().Id+1;
    MallStore.MallList.Add(mallDTO);

    return Ok(mallDTO);


    }



    }
}

# We can also give a route to the new created Mall object by setting an explicit name to the mall get method which has a specific Id

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DotNetApi.Data;
using DotNetApi.Models.Dto;
using Microsoft.AspNetCore.Mvc;

namespace DotNetApi.Controllers
{
    [ApiController]
    [Route("api/Mall")]
    public class MallController : ControllerBase
    {
/*

            GET REQUEST AND ID CODES


*/     
        [HttpGet]
         [ProducesResponseType(StatusCodes.Status200OK)]
        public ActionResult<IEnumerable<MallDTO>> GetMall(){
            return Ok(MallStore.MallList);

        }


         [HttpGet("{Id:int}",Name="GetMall")]
         [ProducesResponseType(StatusCodes.Status201Created)]
         [ProducesResponseType(StatusCodes.Status400BadRequest)]
         [ProducesResponseType(StatusCodes.Status404NotFound)]

        public ActionResult<MallDTO> GetOneMall(int Id){
            if (Id <= 0){
                return BadRequest();
            }
            var Mall = MallStore.MallList.FirstOrDefault(x=>x.Id == Id);
            if (Mall == null){
                return NotFound();
            }
            return Ok(Mall);
        }



    /*
    
            HTTP POST REQUEST 
    
    */

    [HttpPost]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public ActionResult<MallDTO> CreateMall([FromBody]MallDTO mallDTO){

    if(mallDTO == null){
        return BadRequest(mallDTO);
    } 

    if(mallDTO.Id>0){
        return StatusCode(StatusCodes.Status500InternalServerError);
    }
    mallDTO.Id = MallStore.MallList.OrderByDescending(u=>u.Id).FirstOrDefault().Id+1;
    MallStore.MallList.Add(mallDTO);

    return CreatedAtRoute("GetMall", new{Id = mallDTO.Id}, mallDTO);


    }



    }
}

# We can also set a required and max length for the Model Dto so as to ensure that our users do the right thing 

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DotNetApi.Models.Dto
{
    public class MallDTO
    {
        public int Id { get; set; }

        [Required ]
        [MaxLength(50)]
        public string Name { get; set; } = "Name";
    }
}

#  Since we use the [ApiConroller] in the controller class, it give us a basic feature of the Controller.

# If we disable it, we will need to explicitly check things


using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DotNetApi.Data;
using DotNetApi.Models.Dto;
using Microsoft.AspNetCore.Mvc;

namespace DotNetApi.Controllers
{
   // [ApiController]
    [Route("api/Mall")]
    public class MallController : ControllerBase
    {
/*

            GET REQUEST AND ID CODES


*/     
        [HttpGet]
         [ProducesResponseType(StatusCodes.Status200OK)]
        public ActionResult<IEnumerable<MallDTO>> GetMall(){
            return Ok(MallStore.MallList);

        }


         [HttpGet("{Id:int}",Name="GetMall")]
         [ProducesResponseType(StatusCodes.Status201Created)]
         [ProducesResponseType(StatusCodes.Status400BadRequest)]
         [ProducesResponseType(StatusCodes.Status404NotFound)]

        public ActionResult<MallDTO> GetOneMall(int Id){
            if (Id <= 0){
                return BadRequest();
            }
            var Mall = MallStore.MallList.FirstOrDefault(x=>x.Id == Id);
            if (Mall == null){
                return NotFound();
            }
            return Ok(Mall);
        }



    /*
    
            HTTP POST REQUEST 
    
    */

    [HttpPost]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public ActionResult<MallDTO> CreateMall([FromBody]MallDTO mallDTO){

        if(!ModelState.IsValid){
            return BadRequest(ModelState);
        }

    if(mallDTO == null){
        return BadRequest(mallDTO);
    } 

    if(mallDTO.Id>0){
        return StatusCode(StatusCodes.Status500InternalServerError);
    }
    mallDTO.Id = MallStore.MallList.OrderByDescending(u=>u.Id).FirstOrDefault().Id+1;
    MallStore.MallList.Add(mallDTO);

    return CreatedAtRoute("GetMall", new{Id = mallDTO.Id}, mallDTO);


    }



    }
}


# To make the Name field unique we need to do this manually

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DotNetApi.Data;
using DotNetApi.Models.Dto;
using Microsoft.AspNetCore.Mvc;

namespace DotNetApi.Controllers
{
    [ApiController]
    [Route("api/Mall")]
    public class MallController : ControllerBase
    {
/*

            GET REQUEST AND ID CODES


*/     
        [HttpGet]
         [ProducesResponseType(StatusCodes.Status200OK)]
        public ActionResult<IEnumerable<MallDTO>> GetMall(){
            return Ok(MallStore.MallList);

        }


         [HttpGet("{Id:int}",Name="GetMall")]
         [ProducesResponseType(StatusCodes.Status201Created)]
         [ProducesResponseType(StatusCodes.Status400BadRequest)]
         [ProducesResponseType(StatusCodes.Status404NotFound)]

        public ActionResult<MallDTO> GetOneMall(int Id){
            if (Id <= 0){
                return BadRequest();
            }
            var Mall = MallStore.MallList.FirstOrDefault(x=>x.Id == Id);
            if (Mall == null){
                return NotFound();
            }
            return Ok(Mall);
        }



    /*
    
            HTTP POST REQUEST 
    
    */

    [HttpPost]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public ActionResult<MallDTO> CreateMall([FromBody]MallDTO mallDTO){


    if(MallStore.MallList.FirstOrDefault(u=>u.Name.ToLower()==mallDTO.Name.ToLower())!=null)
    {
        ModelState.AddModelError("CustomError","Name already exists");
        return BadRequest(ModelState);
    }


    if(mallDTO == null){
        return BadRequest(mallDTO);
    } 

    if(mallDTO.Id>0){
        return StatusCode(StatusCodes.Status500InternalServerError);
    }
    mallDTO.Id = MallStore.MallList.OrderByDescending(u=>u.Id).FirstOrDefault().Id+1;
    MallStore.MallList.Add(mallDTO);

    return CreatedAtRoute("GetMall", new{Id = mallDTO.Id}, mallDTO);


    }


# We can also Delete A Mall Objects
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DotNetApi.Data;
using DotNetApi.Models.Dto;
using Microsoft.AspNetCore.Mvc;

namespace DotNetApi.Controllers
{
    [ApiController]
    [Route("api/Mall")]
    public class MallController : ControllerBase
    {
/*

            GET REQUEST AND ID CODES


*/     
        [HttpGet]
         [ProducesResponseType(StatusCodes.Status200OK)]
        public ActionResult<IEnumerable<MallDTO>> GetMall(){
            return Ok(MallStore.MallList);

        }


         [HttpGet("{Id:int}",Name="GetMall")]
         [ProducesResponseType(StatusCodes.Status201Created)]
         [ProducesResponseType(StatusCodes.Status400BadRequest)]
         [ProducesResponseType(StatusCodes.Status404NotFound)]

        public ActionResult<MallDTO> GetOneMall(int Id){
            if (Id <= 0){
                return BadRequest();
            }
            var Mall = MallStore.MallList.FirstOrDefault(x=>x.Id == Id);
            if (Mall == null){
                return NotFound();
            }
            return Ok(Mall);
        }



    /*
    
            HTTP POST REQUEST 
    
    */

    [HttpPost]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public ActionResult<MallDTO> CreateMall([FromBody]MallDTO mallDTO){


    if(MallStore.MallList.FirstOrDefault(u=>u.Name.ToLower()==mallDTO.Name.ToLower())!=null)
    {
        ModelState.AddModelError("CustomError","Name already exists");
        return BadRequest(ModelState);
    }


    if(mallDTO == null){
        return BadRequest(mallDTO);
    } 

    if(mallDTO.Id>0){
        return StatusCode(StatusCodes.Status500InternalServerError);
    }
    mallDTO.Id = MallStore.MallList.OrderByDescending(u=>u.Id).FirstOrDefault().Id+1;
    MallStore.MallList.Add(mallDTO);

    return CreatedAtRoute("GetMall", new{Id = mallDTO.Id}, mallDTO);


    }

/*

HTTP DELETE REQUEST
*/

[HttpDelete("{Id:int}", Name="DeleteMall")]
[ProducesResponseType(StatusCodes.Status204NoContent)]
[ProducesResponseType(StatusCodes.Status400BadRequest)]
[ProducesResponseType(StatusCodes.Status404NotFound)]

public IActionResult DeleteMall(int Id){

if(Id ==0){
    return BadRequest();
}

var mall = MallStore.MallList.FirstOrDefault(m => m.Id == Id);
if(mall == null){
    return NotFound();
}
MallStore.MallList.Remove(mall);
return NoContent();



}



    }
}



















    }
}























































