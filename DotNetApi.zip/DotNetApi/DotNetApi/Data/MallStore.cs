using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DotNetApi.Models.Dto;

namespace DotNetApi.Data
{
    public static class MallStore
    {
     public static List<MallDTO> MallList =  new List<MallDTO>{
                new MallDTO{Id = 1, Name = "Solomon", Age=10, Contact="0599626272"},
                new MallDTO{Id = 2, Name = "Whiskey", Age=11, Contact="0599626272"},
                new MallDTO{Id = 3, Name = "Jack", Age=12, Contact="0599626272"},
                new MallDTO{Id = 4, Name = "Jill", Age=13, Contact="0599626272"},
                new MallDTO{Id = 5, Name = "Max", Age=14, Contact="0599626272"},
                new MallDTO{Id = 6, Name = "Charlie", Age=15, Contact="0599626272"},

            };
    }
}