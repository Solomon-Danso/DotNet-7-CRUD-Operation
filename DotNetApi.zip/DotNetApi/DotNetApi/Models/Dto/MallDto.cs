using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DotNetApi.Models.Dto
{
    public class MallDTO
    {
        public int Id { get; set; }

        [Required ]
        [MaxLength(50)]
        public string Name { get; set; } = "Name";

        [Required ]
        public int Age { get; set; }

        [Required ]
        public string ImageUrl { get; set; }

        [Required ]
        public string Location { get; set; } = "Location";
        public string Contact { get; set; } = "Contact";
    
    }
}