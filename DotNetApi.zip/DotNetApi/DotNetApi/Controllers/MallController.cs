using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DotNetApi.Data;
using DotNetApi.Models.Dto;
using Microsoft.AspNetCore.Mvc;

namespace DotNetApi.Controllers
{
    [ApiController]
    [Route("api/Mall")]
    public class MallController : ControllerBase
    {
//Logging
    private readonly ILogger<MallController> _logger;
    public MallController(ILogger<MallController> logger)
    {
        _logger = logger;
    }



/*

            GET REQUEST AND ID CODES


*/     
        [HttpGet]
         [ProducesResponseType(StatusCodes.Status200OK)]
        public ActionResult<IEnumerable<MallDTO>> GetMall(){
            _logger.LogInformation("Getting All Mall Objects");
            return Ok(MallStore.MallList);

        }


         [HttpGet("{Id:int}",Name="GetMall")]
         [ProducesResponseType(StatusCodes.Status201Created)]
         [ProducesResponseType(StatusCodes.Status400BadRequest)]
         [ProducesResponseType(StatusCodes.Status404NotFound)]

        public ActionResult<MallDTO> GetOneMall(int Id){
            if (Id <= 0){
                _logger.LogError("The Id is "+Id);
                return BadRequest();
            }
            var Mall = MallStore.MallList.FirstOrDefault(x=>x.Id == Id);
            if (Mall == null){
                return NotFound();
            }
            return Ok(Mall);
        }



    /*
    
            HTTP POST REQUEST 
    
    */

    [HttpPost]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public ActionResult<MallDTO> CreateMall([FromBody]MallDTO mallDTO){


    if(MallStore.MallList.FirstOrDefault(u=>u.Name.ToLower()==mallDTO.Name.ToLower())!=null)
    {
        ModelState.AddModelError("CustomError","Name already exists");
        return BadRequest(ModelState);
    }


    if(mallDTO == null){
        return BadRequest(mallDTO);
    } 

    if(mallDTO.Id>0){
        return StatusCode(StatusCodes.Status500InternalServerError);
    }
    mallDTO.Id = MallStore.MallList.OrderByDescending(u=>u.Id).FirstOrDefault().Id+1;
    MallStore.MallList.Add(mallDTO);

    return CreatedAtRoute("GetMall", new{Id = mallDTO.Id}, mallDTO);


    }

/*

HTTP DELETE REQUEST
*/

[HttpDelete("{Id:int}", Name="DeleteMall")]
[ProducesResponseType(StatusCodes.Status204NoContent)]
[ProducesResponseType(StatusCodes.Status400BadRequest)]
[ProducesResponseType(StatusCodes.Status404NotFound)]

public IActionResult DeleteMall(int Id){

if(Id ==0){
    return BadRequest();
}

var mall = MallStore.MallList.FirstOrDefault(m => m.Id == Id);
if(mall == null){
    return NotFound();
}
MallStore.MallList.Remove(mall);
return NoContent();


}

/*

HTTP PUT Request

*/

[HttpPut("{Id:int}",Name="UpdateMall")]
[ProducesResponseType(StatusCodes.Status204NoContent)]
[ProducesResponseType(StatusCodes.Status400BadRequest)]


public IActionResult UpdateMall(int Id,[FromBody]MallDTO mallDTO){

if(Id==null || Id != mallDTO.Id){
    return BadRequest();
}

var mall = MallStore.MallList.FirstOrDefault(m => m.Id == Id);
mall.Name = mallDTO.Name;
mall.Age = mallDTO.Age;
mall.Contact = mallDTO.Contact;
return NoContent();


}





    }
}