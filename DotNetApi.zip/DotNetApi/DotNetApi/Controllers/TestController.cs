using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DotNetApi.Data;
using DotNetApi.Models;
using Microsoft.AspNetCore.Mvc;

namespace DotNetApi.Controllers
{
    [ApiController]
    [Route("api/Test")]
    public class TestController : ControllerBase
    {
        [HttpGet]
        public ActionResult<IEnumerable<MallModel>> GetTest(){
            return Ok(MallStore.MallList);
        }

        [HttpGet("Solomon")]
        public ActionResult<MallModel> GetOne(int Solomon){
            return Ok(MallStore.MallList.FirstOrDefault(x=>x.Id == Solomon));
        }
    }
}